package library;

import java.util.ArrayList;
import java.util.List;

/**
 * @author sephiroth
 */
public class ValidatorClasse implements Validator {

	/**
	 * 
	 */
	private static final long	serialVersionUID	= 1L;
	public static final Boolean	EXCLUSION_SAUF		= false;
	public static final Boolean	INCLUSION_SAUF		= true;
	private Boolean				type				= false;
	public List<String>			elements			= new ArrayList<String>();

	/**
	 * @return List<String>
	 */
	public List<String> getElements() {

		return this.elements;
	}

	/**
	 * @param elements
	 */
	public void setElements(final List<String> elements) {

		this.elements = elements;
	}

	public Boolean validate(Object event, Long time) throws Exception {

		for (Object e : elements) {

			if (event.getClass().getName().equals(e)) {

				if (type == EXCLUSION_SAUF) {

					return true;

				} else {

					return false;

				}

			}

			if (type == EXCLUSION_SAUF) {

				return false;

			} else {

				return true;

			}

		}

		throw new Exception(
						"elements est null ou un probleme inconnu est survenu");

	}

	/**
	 * @param type
	 */
	public void setType(final Boolean type) {

		this.type = type;

	}

	/**
	 * @return Boolean
	 */
	public Boolean getType() {

		return this.type;

	}
}
