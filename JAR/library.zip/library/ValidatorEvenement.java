package library;

import java.util.ArrayList;
import java.util.List;

/**
 * @author sephiroth
 */
public class ValidatorEvenement implements Validator {

	private Boolean				enregistrement		= false;
	private List<Object>		debut				= new ArrayList<Object>();
	private List<Object>		fin					= new ArrayList<Object>();

	/**
	 * 
	 */
	private static final long	serialVersionUID	= 1L;

	public Boolean validate(Object event, Long time) throws Exception {

		if (enregistrement.booleanValue()) {

			for (Object o : fin) {

				if (o.getClass().getName().equals(event.getClass().getName())) {
					this.enregistrement = false;
				}

			}

		} else {

			for (Object o : debut) {

				if (o.getClass().getName().equals(event.getClass().getName())) {
					this.enregistrement = true;
				}

			}

		}
		return enregistrement;
	}

	/**
	 * @return List<Object>
	 */
	public List<Object> getDebut() {

		return this.debut;

	}

	/**
	 * @return List<Object>
	 */
	public List<Object> getFin() {

		return this.fin;

	}

	/**
	 * @param debut
	 */
	public void setDebut(final List<Object> debut) {

		this.debut = debut;

	}

	/**
	 * @param fin
	 */
	public void setFin(final List<Object> fin) {

		this.fin = fin;

	}

}
